<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=sandalhouse', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 1. Alter customers table
    $stmt = $pdo->query("SHOW COLUMNS FROM customers LIKE 'wallet_balance'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE customers ADD COLUMN wallet_balance DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER balance");
        echo "Migration: Added wallet_balance column to customers table.\n";
    } else {
        echo "Migration: Column wallet_balance already exists in customers table.\n";
    }

    // 2. Alter invoices table - wallet_amount_used
    $stmt = $pdo->query("SHOW COLUMNS FROM invoices LIKE 'wallet_amount_used'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE invoices ADD COLUMN wallet_amount_used DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER due_amount");
        echo "Migration: Added wallet_amount_used column to invoices table.\n";
    } else {
        echo "Migration: Column wallet_amount_used already exists in invoices table.\n";
    }

    // 3. Alter invoices table - wallet_amount_credited
    $stmt = $pdo->query("SHOW COLUMNS FROM invoices LIKE 'wallet_amount_credited'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE invoices ADD COLUMN wallet_amount_credited DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER wallet_amount_used");
        echo "Migration: Added wallet_amount_credited column to invoices table.\n";
    } else {
        echo "Migration: Column wallet_amount_credited already exists in invoices table.\n";
    }

    // 4. Alter sales_returns table - refund_method
    $stmt = $pdo->query("SHOW COLUMNS FROM sales_returns LIKE 'refund_method'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE sales_returns ADD COLUMN refund_method VARCHAR(30) NOT NULL DEFAULT 'balance' AFTER total_amount");
        echo "Migration: Added refund_method column to sales_returns table.\n";
    } else {
        echo "Migration: Column refund_method already exists in sales_returns table.\n";
    }

    // 5. Create customer_wallet_transactions table
    $pdo->exec("CREATE TABLE IF NOT EXISTS customer_wallet_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_id INT NOT NULL,
        transaction_type ENUM('credit', 'debit') NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        opening_balance DECIMAL(12,2) NOT NULL,
        closing_balance DECIMAL(12,2) NOT NULL,
        reference_type VARCHAR(50) NOT NULL,
        reference_id INT DEFAULT NULL,
        reference_no VARCHAR(50) DEFAULT NULL,
        remarks TEXT DEFAULT NULL,
        branch_id INT NOT NULL DEFAULT 0,
        created_by INT NOT NULL,
        created_at DATETIME NOT NULL,
        KEY customer_id (customer_id),
        KEY created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    echo "Migration: Verified customer_wallet_transactions table.\n";

    echo "All database migrations successfully completed.\n";

} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
}
